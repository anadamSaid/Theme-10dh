<?php 
define('_PS_MODE_DEV_', true);